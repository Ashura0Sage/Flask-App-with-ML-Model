from flask import Flask
from flask import Flask,request,redirect,url_for,session,abort,flash,jsonify,g
from flask import render_template
from flask import make_response
from functions import * 



def init_apiroutes(app):
    if app:
        print("API routes will be here ")
        
def init_pageroutes(app):
    if app:
        app.add_url_rule('/predict','predict', predict, methods = ['GET', 'POST'])
        app.add_url_rule('/','home', home, methods = ['GET', 'POST'])
        
        
