from flask import Flask,render_template,url_for,request
from routes import init_apiroutes
from routes import init_pageroutes


application = app = Flask(__name__)  


init_apiroutes(app)
init_pageroutes(app)

if __name__ == '__main__':
	app.run(debug=True)