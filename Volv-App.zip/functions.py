import pandas as pd 
import pickle
from sklearn.feature_extraction.text import CountVectorizer
import joblib



filename = 'C:/Users/Admin/Desktop/Volv-App/static/model/finalized_model.sav'
count_vect1 = CountVectorizer(vocabulary=pickle.load(open("C:/Users/Admin/Desktop/Volv-App/static/model/feature.pkl", "rb")))


def home():
	return render_template('home.html')


def predict():
    clf = joblib.load(filename)
    print("reached insde")
    print(clf)
    if request.method == 'POST':
        print("inside if")
        message = request.form['message']
        data = [message]
        vect = count_vect1.transform(data).toarray()
        my_prediction = clf.predict(vect)
        my_prediction = my_prediction[0]
        return render_template('result.html',prediction = my_prediction)
    else:
        return render_template('home.html')
